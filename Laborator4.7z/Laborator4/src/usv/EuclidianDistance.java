package usv;

public class EuclidianDistance  extends Exception {
	
	public EuclidianDistance(String message) {
        super(message);
    }
	
	protected static double distanceEuclidian(double[] p,double[] p2 ) {
		// TODO Auto-generated method stub
		double sum=0.00;
    	double d=0.00;
    	for(int k=0; k<p.length-1; k++)
    	{
    		sum+=(p[k]-p2[k])*(p[k]-p2[k]);
    	}
    	d=Math.sqrt(sum);
    	return d;
	}

}
