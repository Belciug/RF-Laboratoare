package usv;

import java.text.DecimalFormat;

public class MainClass {
	
	
	public static void main(String[] args) {
		double[][] learningSet;
		
		try {
			learningSet = FileUtils
					.readLearningSetFromFile("in.txt");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length -1;
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns,
					numberOfFeatures));
			double[][] matrix = new double[numberOfPatterns][numberOfPatterns];
			// USVInputFileCustomException.calculateEuclidian(learningSet[0],learningSet[1]);
			int counter = 0;
			DecimalFormat df = new DecimalFormat("#.##");
			for (int i = 0; i < numberOfPatterns; i++) {
				for (int j = i+1; j < numberOfPatterns; j++) {
					double euclidianDistance = EuclidianDistance.distanceEuclidian(learningSet[i], learningSet[j]);
					counter++;
					matrix[i][j] = euclidianDistance;
					matrix[j][i] = euclidianDistance;

				}

			}
			System.out.println(" --- > " + counter);
			for (int i = 0; i < numberOfPatterns; i++) {
				for (int j = 0; j < numberOfPatterns; j++) {
					double value = Math.floor(matrix[i][j] * 100) / 100;
					System.out.print(value + " ");

				}
				System.out.println();
			}
			System.out.println("\n\n");
			double minDistance = Double.MAX_VALUE;
			int lineToCalculateClass = learningSet.length-1;
			int line=-1;
			for (int j = 0; j<numberOfPatterns; j++)
			{if (j == lineToCalculateClass)
				{
					continue;
				}
				if(matrix[lineToCalculateClass][j] < minDistance )
				{
					minDistance= matrix[lineToCalculateClass][j];
					line= j;
				
				}
				
			}
			System.out.println("Class "+minDistance);
			System.out.println("Class "+learningSet[line][learningSet[0].length -1]);
			
		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
	}

}
