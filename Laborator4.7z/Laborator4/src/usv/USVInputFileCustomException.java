package usv;

public class USVInputFileCustomException extends Exception {

    public USVInputFileCustomException(String message) {
        super(message);
    }
    
   /* public static void Euclidian(double[][] learningSet, int p, int i, int j)
    {
    	double sum=0.00;
    	double d=0.00;
    	for(int k=0; k<p; k++)
    	{
    		sum+=(learningSet[i][k]-learningSet[j][k])*(learningSet[i][k]-learningSet[j][k]);
    	}
    	d=Math.sqrt(sum);
    	System.out.println(sum);
    }*/

	
	
}