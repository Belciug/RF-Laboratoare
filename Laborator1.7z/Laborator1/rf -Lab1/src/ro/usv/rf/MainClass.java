package ro.usv.rf;

import org.knowm.xchart.QuickChart;
import org.knowm.xchart.SwingWrapper;
import org.knowm.xchart.XYChart;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double[][] learningSet = FileUtils.readLearningSetFromFile("E:\\An4\\SEM2\\RF-lab\\lab1\\rf -Lab1\\src\\ro\\usv\\rf\\in.txt");
		FileUtils.writeLearningSetToFile("E:\\An4\\SEM2\\RF-lab\\lab1\\rf -Lab1\\src\\ro\\usv\\rf\\out.csv", normalizeLearningSet(learningSet));
		//FileUtils.writeLearningSetToFile("E:\\An4\\Eclipse 4-6-1 Neon - Java IDE x64\\rf\\src\\ro\\usv\\rf\\out.csv", learningSet);
		
	}
	
	private static double[][] normalizeLearningSet(double[][] learningSet) 
	{ 
		double[][] normalizedLearningSet = new double[learningSet.length][learningSet[0].length];
		
		double[][] min_bound= new double[learningSet.length][learningSet[0].length];
		double[][] max_bound= new double[learningSet.length][learningSet[0].length];
		
		for(int i=0; i<learningSet.length-1;i++)
		{
			
			        double min = Integer.MAX_VALUE;
			        for ( int j = 0; j < learningSet [ i ].length; j++ )
			            if ( learningSet [ j ] [ i ] < min )
			                min = learningSet [ j ] [ i ];
			min_bound[0][i]=min;
			// System.out.println( "Min of row " + i + " = " + min );
		}
		//for(int i=0; i<min_bound.length-1; i++)
		//	System.out.println(min_bound[0][i]+" ");
		
		 for ( int i = 0; i < learningSet.length-1; i++ )
		    {
		       double max = Integer.MIN_VALUE;
		        for ( int j = 0; j < learningSet [ i ].length; j++ )
		            if ( learningSet [ j] [ i ] > max )
		                max = learningSet [ j ] [ i ];
		       max_bound[0][i]=max;
		      //   System.out.println( "Maximum of row " + i + " = " + max );
		    }
		// for(int i=0; i<min_bound.length-1; i++)
		//		System.out.println(max_bound[0][i]+" ");
			
		 
		for(int n = 0; n < learningSet.length; n++) //for each row 
		{
	    
			for(int p = 0; p < learningSet[n].length; p++)   
			{ 
				normalizedLearningSet[n][p]= (learningSet[n][p]-min_bound[0][p])/(max_bound[0][p]-min_bound[0][p]);	
			}  
			
		}
		
		double[] xData = new double[learningSet.length] ;
	    double[] yData = new double[learningSet.length] ;
	    
	    for(int n = 0; n < learningSet.length; n++) //for each row 
		{
	    
				xData[n]=normalizedLearningSet[n][0];	  
		}
	    for(int n = 0; n < learningSet.length; n++) //for each row 
		{
	    
				yData[n]=normalizedLearningSet[n][1];	  
		}
	    for(int n = 0; n < learningSet.length; n++) //for each row 
		{
	    
	    	System.out.print(xData[n]+" ");
		}
	    
	    for(int n = 0; n < learningSet.length; n++) //for each row 
		{
	    
	    	System.out.print(yData[n]+" ");
		}
	    
	    // Create Chart
	    XYChart chart = QuickChart.getChart("Sample Chart", "X", "Y", "y(x)", xData, yData);
	 
	    // Show it
	    new SwingWrapper(chart).displayChart();
	 
	 
		
		
		return normalizedLearningSet;  
	}
	

}
