package usv;

public class MainClass {
	
	
	public static void main(String[] args) {
		double[][] learningSet;
		learningSet = FileUtils.readLearningSetFromFile("E:\\An4\\SEM2\\RF-lab\\lab3-rezolvare\\src\\usv\\in.txt");
		int numberOfPatterns = learningSet.length;
		int numberOfFeatures = learningSet[0].length;
		System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));

		USVInputFileCustomException.Euclidan(learningSet,numberOfPatterns,numberOfFeatures);
		USVInputFileCustomException.Cebisev3(learningSet,numberOfPatterns,numberOfFeatures);
		USVInputFileCustomException.CityBlock2(learningSet,numberOfPatterns,numberOfFeatures);
		USVInputFileCustomException.Mahalanobis2(learningSet,numberOfPatterns,numberOfFeatures);
		
		/*	try {
				}// catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
	*/}

}
